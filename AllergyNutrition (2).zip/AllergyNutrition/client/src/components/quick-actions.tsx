import { Zap, Plus, Calendar, Settings } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

interface QuickActionsProps {
  onAddFood: () => void;
  onViewToday: () => void;
  onManageFoods: () => void;
  completedToday: number;
  totalToday: number;
}

export default function QuickActions({ 
  onAddFood, 
  onViewToday, 
  onManageFoods, 
  completedToday, 
  totalToday 
}: QuickActionsProps) {
  const progressPercentage = totalToday > 0 ? Math.round((completedToday / totalToday) * 100) : 0;

  return (
    <div className="bg-white rounded-xl sm:rounded-2xl shadow-lg p-3 sm:p-6 space-y-3 sm:space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-base sm:text-lg font-semibold">Quick Actions</h3>
        <Zap className="w-4 h-4 sm:w-5 sm:h-5 text-orange-500" />
      </div>

      {/* Progress Badge - Mobile Optimized */}
      <div className="flex items-center justify-center p-3 sm:p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg sm:rounded-xl">
        <div className="text-center">
          <div className="text-xl sm:text-2xl font-bold text-blue-600">
            {completedToday}/{totalToday}
          </div>
          <div className="text-xs sm:text-sm text-gray-600">
            Today ({progressPercentage}%)
          </div>
        </div>
      </div>

      {/* Quick Action Buttons - Mobile Optimized */}
      <div className="grid grid-cols-2 gap-2 sm:gap-3">
        <Button
          onClick={onAddFood}
          variant="outline"
          className="flex flex-col items-center p-2 sm:p-4 h-16 sm:h-20 minecraft-action-btn"
        >
          <Plus className="w-4 h-4 sm:w-5 sm:h-5 mb-1" />
          <span className="text-[10px] sm:text-xs">Add Food</span>
        </Button>

        <Button
          onClick={onViewToday}
          variant="outline"
          className="flex flex-col items-center p-2 sm:p-4 h-16 sm:h-20 minecraft-action-btn"
        >
          <Calendar className="w-4 h-4 sm:w-5 sm:h-5 mb-1" />
          <span className="text-[10px] sm:text-xs">View Today</span>
        </Button>

        <Button
          onClick={onManageFoods}
          variant="outline"
          className="flex flex-col items-center p-2 sm:p-4 h-16 sm:h-20 minecraft-action-btn"
        >
          <Settings className="w-4 h-4 sm:w-5 sm:h-5 mb-1" />
          <span className="text-[10px] sm:text-xs">Manage</span>
        </Button>

        <Button
          onClick={() => window.location.reload()}
          variant="outline"
          className="flex flex-col items-center p-2 sm:p-4 h-16 sm:h-20 minecraft-action-btn"
        >
          <div className="w-4 h-4 sm:w-5 sm:h-5 mb-1 animate-spin">⟳</div>
          <span className="text-[10px] sm:text-xs">Refresh</span>
        </Button>
      </div>


    </div>
  );
}