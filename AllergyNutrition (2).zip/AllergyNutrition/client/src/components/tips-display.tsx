import { useState, useEffect } from 'react';
import { Lightbulb } from 'lucide-react';

const tips = [
  // Add your custom tips here
];

export default function TipsDisplay() {
  const [currentTip, setCurrentTip] = useState(0);

  useEffect(() => {
    if (tips.length === 0) return;
    
    const interval = setInterval(() => {
      setCurrentTip((prev) => (prev + 1) % tips.length);
    }, 15000); // Change every 15 seconds

    return () => clearInterval(interval);
  }, []);

  if (tips.length === 0) {
    return null; // Don't render anything if no tips
  }

  return (
    <div className="bg-gradient-to-r from-yellow-50 to-orange-50 rounded-lg sm:rounded-xl p-3 sm:p-4 border border-yellow-200 minecraft-tip-box">
      <div className="flex items-start space-x-2 sm:space-x-3">
        <div className="minecraft-tip-icon flex-shrink-0">
          <Lightbulb className="w-4 h-4 sm:w-5 sm:h-5 text-yellow-600" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="text-xs sm:text-sm text-gray-700 minecraft-tip-text">
            {tips[currentTip]}
          </div>
          <div className="flex items-center justify-between mt-2">
            <div className="flex space-x-1">
              {tips.map((_, index) => (
                <div
                  key={index}
                  className={`w-1.5 h-1.5 sm:w-2 sm:h-2 rounded-full transition-all duration-300 ${
                    index === currentTip 
                      ? 'bg-yellow-500 scale-125' 
                      : 'bg-yellow-200'
                  }`}
                />
              ))}
            </div>
            <span className="text-[10px] sm:text-xs text-gray-500 ml-2 flex-shrink-0">
              {currentTip + 1}/{tips.length}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}