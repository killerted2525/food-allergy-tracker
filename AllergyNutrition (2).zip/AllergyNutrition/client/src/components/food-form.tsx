import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { insertFoodSchema, type Food } from "@shared/schema";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { formatDate } from "@/lib/date-utils";

const formSchema = insertFoodSchema.extend({
  startDate: z.string().min(1, "Start date is required"),
  mealType: z.enum(["breakfast", "lunch", "dinner", "snack", "any"]).default("any"),
});

type FormData = z.infer<typeof formSchema>;

interface FoodFormProps {
  food?: Food;
  onSuccess?: () => void;
}

const colorOptions = [
  { value: 'blue', label: 'Blue', color: '#007AFF' },
  { value: 'green', label: 'Green', color: '#34C759' },
  { value: 'orange', label: 'Orange', color: '#FF9500' },
  { value: 'red', label: 'Red', color: '#FF3B30' },
  { value: 'purple', label: 'Purple', color: '#AF52DE' },
  { value: 'pink', label: 'Pink', color: '#FF2D92' },
  { value: 'yellow', label: 'Yellow', color: '#FFCC00' },
  { value: 'teal', label: 'Teal', color: '#30B0C7' },
  { value: 'mint', label: 'Mint', color: '#00C7BE' },
  { value: 'indigo', label: 'Indigo', color: '#5856D6' },
];

export default function FoodForm({ food, onSuccess }: FoodFormProps) {
  const [selectedColor, setSelectedColor] = useState(food?.color || 'blue');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: food?.name || "",
      instructions: food?.instructions || "",
      color: food?.color || 'blue',
      frequency: food?.frequency || "Every day",
      startDate: food?.startDate || formatDate(new Date()),
      mealType: food?.mealType || "any",
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: FormData) => {
      const response = await apiRequest('POST', '/api/foods', data);
      const newFood = await response.json();
      
      // Generate schedule for the new food
      const endDate = new Date();
      endDate.setMonth(endDate.getMonth() + 3); // 3 months ahead
      
      await apiRequest('POST', `/api/foods/${newFood.id}/generate-schedule`, {
        startDate: data.startDate,
        endDate: formatDate(endDate),
      });
      
      return newFood;
    },
    onSuccess: (newFood) => {
      queryClient.invalidateQueries({ queryKey: ['/api/foods'] });
      queryClient.invalidateQueries({ queryKey: ['/api/schedule'] });
      form.reset();
      setSelectedColor('blue');
      onSuccess?.();
      toast({
        title: "Food added",
        description: "Food has been added to your schedule.",
      });
    },
    onError: (error) => {
      console.error('Error adding food:', error);
      toast({
        title: "Error",
        description: "Failed to add food.",
        variant: "destructive",
      });
    }
  });

  const updateMutation = useMutation({
    mutationFn: async (data: FormData) => {
      return apiRequest('PATCH', `/api/foods/${food!.id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/foods'] });
      onSuccess?.();
      toast({
        title: "Food updated",
        description: "Food has been updated successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update food.",
        variant: "destructive",
      });
    }
  });

  const onSubmit = (data: FormData) => {
    if (food) {
      updateMutation.mutate(data);
    } else {
      createMutation.mutate(data);
    }
  };

  const isLoading = createMutation.isPending || updateMutation.isPending;

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Food Name</FormLabel>
              <FormControl>
                <Input placeholder="e.g., Peanut Butter" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="instructions"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Instructions</FormLabel>
              <FormControl>
                <Textarea 
                  placeholder="e.g., 1 teaspoon with breakfast" 
                  rows={3} 
                  {...field} 
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="color"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Color</FormLabel>
              <FormControl>
                <div className="grid grid-cols-5 gap-2">
                  {colorOptions.map((option) => (
                    <button
                      key={option.value}
                      type="button"
                      className={`w-10 h-10 rounded-xl border-2 transition-all duration-200 ${
                        selectedColor === option.value 
                          ? 'ring-2 ring-blue-500 scale-110 shadow-lg' 
                          : 'border-gray-200 hover:scale-105 hover:shadow-md'
                      }`}
                      style={{ backgroundColor: option.color }}
                      onClick={() => {
                        setSelectedColor(option.value);
                        field.onChange(option.value);
                      }}
                      title={option.label}
                    />
                  ))}
                </div>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="frequency"
          render={({ field }) => (
            <FormItem>
              <FormLabel>How Often</FormLabel>
              <FormControl>
                <Input 
                  placeholder="e.g., Every day, 3 times per week, Every 2 days" 
                  {...field} 
                />
              </FormControl>
              <p className="text-xs text-gray-500 mt-1">
                Examples: "Every day", "3 times per week", "Every 2 days", "Twice daily"
              </p>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="mealType"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Meal Category</FormLabel>
              <FormControl>
                <Select value={field.value} onValueChange={field.onChange}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select meal category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="breakfast">🌅 Breakfast</SelectItem>
                    <SelectItem value="lunch">🍽️ Lunch</SelectItem>
                    <SelectItem value="dinner">🌙 Dinner</SelectItem>
                    <SelectItem value="snack">🍪 Snack</SelectItem>
                    <SelectItem value="any">⏰ Any Time</SelectItem>
                  </SelectContent>
                </Select>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="startDate"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Start Date</FormLabel>
              <FormControl>
                <Input type="date" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <Button
          type="submit"
          disabled={isLoading}
          className="w-full gradient-button text-white font-medium py-3 text-base rounded-xl shadow-lg hover:shadow-xl transition-all duration-300"
          style={{ backgroundColor: '#007AFF' }}
        >
          {isLoading ? "Saving..." : food ? "Update Food" : "Add Food to Schedule"}
        </Button>
      </form>
    </Form>
  );
}
