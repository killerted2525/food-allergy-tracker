import { useState } from 'react';
import { Zap, Check, Clock, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { type ScheduleEntry, type Food } from '@shared/schema';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { SoundManager } from '@/lib/sounds';
import { UndoManager } from '@/lib/undo';
import { formatDate } from '@/lib/date-utils';

interface QuickActionsModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedDate: Date;
  scheduleEntries: ScheduleEntry[];
  foods: Food[];
}

export default function QuickActionsModal({ 
  isOpen, 
  onClose, 
  selectedDate,
  scheduleEntries,
  foods 
}: QuickActionsModalProps) {
  const [action, setAction] = useState<'complete' | 'incomplete' | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const soundManager = SoundManager.getInstance();
  const undoManager = UndoManager.getInstance();

  const dateString = formatDate(selectedDate);
  const dayEntries = scheduleEntries.filter(entry => entry.date === dateString);
  const pendingEntries = dayEntries.filter(entry => !entry.isCompleted);
  const completedEntries = dayEntries.filter(entry => entry.isCompleted);

  const quickActionMutation = useMutation({
    mutationFn: async ({ entryIds, isCompleted }: { entryIds: number[]; isCompleted: boolean }) => {
      const promises = entryIds.map(id => 
        apiRequest('PATCH', `/api/schedule/${id}`, { 
          isCompleted,
          completedAt: isCompleted ? new Date().toISOString() : null
        })
      );
      return Promise.all(promises);
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['/api/schedule'] });
      
      undoManager.recordAction('bulk_completion', {
        entryIds: variables.entryIds,
        previousState: !variables.isCompleted
      });

      soundManager.playCompleteSound();
      toast({
        title: `${variables.entryIds.length} foods ${variables.isCompleted ? 'completed' : 'uncompleted'}`,
        description: "Quick action applied successfully",
      });
      onClose();
    },
    onError: () => {
      soundManager.playErrorSound();
      toast({
        title: "Error",
        description: "Failed to update foods",
        variant: "destructive",
      });
    }
  });

  const handleQuickComplete = () => {
    if (pendingEntries.length === 0) return;
    quickActionMutation.mutate({
      entryIds: pendingEntries.map(entry => entry.id),
      isCompleted: true
    });
  };

  const handleQuickUncomplete = () => {
    if (completedEntries.length === 0) return;
    quickActionMutation.mutate({
      entryIds: completedEntries.map(entry => entry.id),
      isCompleted: false
    });
  };

  const getMealGroups = () => {
    const groups: Record<string, ScheduleEntry[]> = {
      breakfast: [],
      lunch: [],
      dinner: [],
      snack: [],
      any: []
    };

    dayEntries.forEach(entry => {
      const food = foods.find(f => f.id === entry.foodId);
      if (food) {
        groups[food.mealType || 'any'].push(entry);
      }
    });

    return groups;
  };

  const mealGroups = getMealGroups();

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Zap className="w-5 h-5 text-orange-500" />
            <span>Quick Actions</span>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="text-sm text-gray-600">
            {selectedDate.toLocaleDateString('en-US', { 
              weekday: 'long', 
              month: 'long', 
              day: 'numeric' 
            })}
          </div>

          {/* Meal Type Quick Actions */}
          <div className="space-y-3">
            {Object.entries(mealGroups).map(([mealType, entries]) => {
              if (entries.length === 0) return null;
              
              const pending = entries.filter(e => !e.isCompleted).length;
              const completed = entries.filter(e => e.isCompleted).length;
              
              return (
                <div key={mealType} className="bg-gray-50 p-3 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium capitalize">
                      {mealType === 'any' ? 'Other' : mealType}
                    </h4>
                    <span className="text-sm text-gray-600">
                      {completed}/{entries.length} completed
                    </span>
                  </div>
                  
                  <div className="flex space-x-2">
                    {pending > 0 && (
                      <Button
                        size="sm"
                        onClick={() => {
                          const pendingIds = entries
                            .filter(e => !e.isCompleted)
                            .map(e => e.id);
                          quickActionMutation.mutate({
                            entryIds: pendingIds,
                            isCompleted: true
                          });
                        }}
                        className="bg-green-600 hover:bg-green-700 text-white"
                      >
                        <Check className="w-3 h-3 mr-1" />
                        Complete {pending}
                      </Button>
                    )}
                    
                    {completed > 0 && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          const completedIds = entries
                            .filter(e => e.isCompleted)
                            .map(e => e.id);
                          quickActionMutation.mutate({
                            entryIds: completedIds,
                            isCompleted: false
                          });
                        }}
                      >
                        <Clock className="w-3 h-3 mr-1" />
                        Reset {completed}
                      </Button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Global Quick Actions */}
          <div className="border-t pt-4 space-y-3">
            {pendingEntries.length > 0 && (
              <Button
                onClick={handleQuickComplete}
                disabled={quickActionMutation.isPending}
                className="w-full bg-green-600 hover:bg-green-700"
              >
                <Check className="w-4 h-4 mr-2" />
                Complete All Pending ({pendingEntries.length})
              </Button>
            )}

            {completedEntries.length > 0 && (
              <Button
                onClick={handleQuickUncomplete}
                disabled={quickActionMutation.isPending}
                variant="outline"
                className="w-full"
              >
                <Clock className="w-4 h-4 mr-2" />
                Reset All Completed ({completedEntries.length})
              </Button>
            )}

            {dayEntries.length === 0 && (
              <div className="text-center py-4 text-gray-500">
                No foods scheduled for this day
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}