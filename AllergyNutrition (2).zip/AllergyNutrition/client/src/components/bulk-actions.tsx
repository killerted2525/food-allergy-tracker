import { useState } from 'react';
import { CheckSquare, Square, X, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { type ScheduleEntry, type Food } from '@shared/schema';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { SoundManager } from '@/lib/sounds';
import { UndoManager } from '@/lib/undo';

interface BulkActionsProps {
  scheduleEntries: ScheduleEntry[];
  foods: Food[];
  date: string;
  onClose: () => void;
}

export default function BulkActions({ scheduleEntries, foods, date, onClose }: BulkActionsProps) {
  const [selectedEntries, setSelectedEntries] = useState<Set<number>>(new Set());
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const soundManager = SoundManager.getInstance();
  const undoManager = UndoManager.getInstance();

  const dayEntries = scheduleEntries.filter(entry => entry.date === date);

  const bulkUpdateMutation = useMutation({
    mutationFn: async ({ entryIds, isCompleted }: { entryIds: number[]; isCompleted: boolean }) => {
      const promises = entryIds.map(id => 
        apiRequest('PATCH', `/api/schedule/${id}`, { 
          isCompleted,
          completedAt: isCompleted ? new Date().toISOString() : null
        })
      );
      return Promise.all(promises);
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['/api/schedule'] });
      
      // Record undo action
      undoManager.recordAction('bulk_completion', {
        entryIds: variables.entryIds,
        previousState: !variables.isCompleted
      });

      soundManager.playCompleteSound();
      toast({
        title: `${variables.entryIds.length} foods ${variables.isCompleted ? 'completed' : 'uncompleted'}`,
        description: "Bulk action applied successfully",
      });
      onClose();
    },
    onError: () => {
      soundManager.playErrorSound();
      toast({
        title: "Error",
        description: "Failed to update foods",
        variant: "destructive",
      });
    }
  });

  const toggleSelection = (entryId: number) => {
    const newSelection = new Set(selectedEntries);
    if (newSelection.has(entryId)) {
      newSelection.delete(entryId);
    } else {
      newSelection.add(entryId);
    }
    setSelectedEntries(newSelection);
  };

  const selectAll = () => {
    if (selectedEntries.size === dayEntries.length) {
      setSelectedEntries(new Set());
    } else {
      setSelectedEntries(new Set(dayEntries.map(entry => entry.id)));
    }
  };

  const handleBulkComplete = (isCompleted: boolean) => {
    if (selectedEntries.size === 0) return;
    bulkUpdateMutation.mutate({
      entryIds: Array.from(selectedEntries),
      isCompleted
    });
  };

  if (dayEntries.length === 0) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-500">No foods scheduled for this day</p>
        <Button onClick={onClose} className="mt-4">Close</Button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Bulk Actions</h3>
        <Button variant="ghost" size="sm" onClick={onClose}>
          <X className="w-4 h-4" />
        </Button>
      </div>

      <div className="flex items-center justify-between bg-gray-50 p-3 rounded-lg">
        <Button
          variant="outline"
          size="sm"
          onClick={selectAll}
          className="flex items-center space-x-2"
        >
          {selectedEntries.size === dayEntries.length ? (
            <CheckSquare className="w-4 h-4" />
          ) : (
            <Square className="w-4 h-4" />
          )}
          <span>
            {selectedEntries.size === dayEntries.length ? 'Deselect All' : 'Select All'}
          </span>
        </Button>
        
        <span className="text-sm text-gray-600">
          {selectedEntries.size} of {dayEntries.length} selected
        </span>
      </div>

      <div className="space-y-2 max-h-60 overflow-y-auto">
        {dayEntries.map(entry => {
          const food = foods.find(f => f.id === entry.foodId);
          if (!food) return null;

          const isSelected = selectedEntries.has(entry.id);
          
          return (
            <div
              key={entry.id}
              onClick={() => toggleSelection(entry.id)}
              className={`p-3 rounded-lg border cursor-pointer transition-all duration-200 ${
                isSelected 
                  ? 'border-blue-300 bg-blue-50' 
                  : 'border-gray-200 bg-white hover:bg-gray-50'
              }`}
            >
              <div className="flex items-center space-x-3">
                <div className={`w-5 h-5 rounded border-2 flex items-center justify-center ${
                  isSelected 
                    ? 'border-blue-500 bg-blue-500' 
                    : 'border-gray-300'
                }`}>
                  {isSelected && <Check className="w-3 h-3 text-white" />}
                </div>
                
                <div 
                  className="w-4 h-4 rounded-full"
                  style={{ backgroundColor: food.color }}
                />
                
                <div className="flex-1">
                  <p className={`font-medium ${entry.isCompleted ? 'line-through text-gray-500' : ''}`}>
                    {food.name}
                  </p>
                  <p className="text-sm text-gray-600">{food.instructions}</p>
                </div>
                
                {entry.isCompleted && (
                  <div className="text-green-600">
                    <Check className="w-4 h-4" />
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {selectedEntries.size > 0 && (
        <div className="flex space-x-3 pt-4 border-t">
          <Button
            onClick={() => handleBulkComplete(true)}
            disabled={bulkUpdateMutation.isPending}
            className="flex-1 bg-green-600 hover:bg-green-700"
          >
            <Check className="w-4 h-4 mr-2" />
            Mark as Completed
          </Button>
          
          <Button
            onClick={() => handleBulkComplete(false)}
            disabled={bulkUpdateMutation.isPending}
            variant="outline"
            className="flex-1"
          >
            <Square className="w-4 h-4 mr-2" />
            Mark as Incomplete
          </Button>
        </div>
      )}
    </div>
  );
}