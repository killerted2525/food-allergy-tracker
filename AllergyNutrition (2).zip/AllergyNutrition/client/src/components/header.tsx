import Logo from "@/components/logo";

export default function Header() {
  return (
    <header className="app-header shadow-sm border-b" style={{ borderColor: 'hsl(var(--apple-border))' }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-center h-16">
          <div className="flex items-center space-x-3">
            <Logo size={32} />
            <h1 className="text-xl font-semibold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              AllergyTracker
            </h1>
          </div>
        </div>
      </div>
    </header>
  );
}
