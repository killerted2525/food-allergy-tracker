# AllergyTracker

A modern web application designed to help users manage and track food allergies and dietary schedules through an intuitive calendar interface.

## Features

- **Calendar-based scheduling** - Visual calendar for tracking food consumption
- **Mobile-friendly design** - Responsive interface optimized for mobile devices
- **Smart tips system** - Helpful tips that rotate every 15 seconds
- **Direct support** - Built-in support button for instant help
- **Persistent data** - All your information is safely stored in a database
- **Start date picker** - Choose when to begin tracking specific foods

## Tech Stack

- **Frontend**: React with TypeScript, Tailwind CSS, shadcn/ui
- **Backend**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Deployment**: Vercel

## Local Development

1. Clone the repository
2. Install dependencies: `npm install`
3. Set up your PostgreSQL database
4. Add your DATABASE_URL to environment variables
5. Run database migrations: `npm run db:push`
6. Start development server: `npm run dev`

## Deployment

This app is configured for easy deployment on Vercel:

1. Connect your GitHub repository to Vercel
2. Add your DATABASE_URL environment variable in Vercel dashboard
3. Deploy automatically on every push to main branch

## Support

Having issues? Use the support button in the app to get help directly via text message.

## License

MIT License - feel free to use this for your own projects!