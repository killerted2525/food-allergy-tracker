# Put Your Food Calendar App Online - Super Simple Guide

## What This Does
This guide will help you put your food calendar app on the internet so anyone can use it from their phone or computer. It's completely free!

---

## STEP 1: Save Your Code Online (GitHub)

### 1A: Create a GitHub Account
1. **Go to github.com** in your web browser
2. **Look for a green button that says "Sign up"** - click it
3. **Type in your email** and make up a password
4. **Pick a username** (like johnsmith123)
5. **Click "Create account"**
6. **Check your email** and click the link they send you

### 1B: Make a Place for Your Code
1. **After logging in**, look for a **green button that says "New"** - click it
2. **Type "food-calendar-app"** in the box that says "Repository name"
3. **Make sure the circle next to "Public" is filled in** (NOT "Private")
4. **Do NOT check any boxes** below that
5. **Click the green "Create repository" button**

### 1C: Put Your Code There
1. **Keep that page open** - you'll need it
2. **Go back to this Replit tab**
3. **Click the 3 dots** next to "Files" on the left side
4. **Click "Download as zip"**
5. **Save it to your Downloads folder** and unzip it

**For Chromebook users:**
1. **Press Ctrl + Alt + T** - this opens the terminal
2. **Type "shell"** and press Enter
3. **A terminal window opens** - this is normal

**For Windows users:**
1. **Press the Windows key and R** at the same time
2. **Type "cmd"** and press Enter
3. **A black window opens** - this is normal

**For Mac users:**
1. **Press Command and Space** at the same time
2. **Type "terminal"** and press Enter
3. **A window opens** - this is normal

**For Chromebook users continue here:**
1. **Type this and press Enter:** `cd /home/chronos/user/Downloads`
2. **Type this and press Enter:** `ls` (this shows your downloaded files)
3. **Look for your zip file** and note the folder name after you unzip it
4. **Type this and press Enter:** `cd` then the name of your unzipped folder

**For Windows/Mac users:**
1. **Type this and press Enter:** `cd Downloads`
2. **Type this and press Enter:** `cd` then the name of your unzipped folder

**For Everyone:**
3. **Now copy and paste these commands ONE AT A TIME** (press Enter after each):

```
git init
```
(Press Enter and wait)

```
git add .
```
(Press Enter and wait)

```
git commit -m "My food calendar app"
```
(Press Enter and wait)

```
git branch -M main
```
(Press Enter and wait)

**Now go back to your GitHub page** and copy the line that starts with "git remote add origin" - paste it and press Enter

**Then copy the line that starts with "git push"** - paste it and press Enter

**If it asks for username/password**, use your GitHub username and password

**Chromebook Note:** If git isn't installed, you might need to enable Linux (beta) in Settings > Advanced > Developers, then install git with: `sudo apt update && sudo apt install git`

---

## STEP 2: Make It a Real Website (Render)

### 2A: Create a Render Account
1. **Go to render.com** in a new tab
2. **Click "Get Started for Free"**
3. **Click the "GitHub" button** (don't type anything)
4. **Click "Authorize Render"** when it asks

### 2B: Make a Database (Where Your Food Info is Saved)
1. **Look for a blue button that says "New +"** - click it
2. **Click "PostgreSQL"**
3. **Fill in these boxes EXACTLY:**
   - **Name:** `food-calendar-db`
   - **Database:** `foodcalendar`
   - **User:** `fooduser`
   - **Region:** Pick the one closest to where you live
   - **Plan:** Make sure it says "Free"
4. **Click "Create Database"**
5. **Wait 2 minutes** - it will say "Available" when ready
6. **Click on the database name**
7. **Scroll down until you see "External Database URL"**
8. **Click the copy button** next to the long text (starts with "postgresql://")
9. **Paste this somewhere** like Notepad - you need it for the next step

### 2C: Make Your Website
1. **Click that blue "New +" button** again
2. **Click "Web Service"**
3. **Click "Connect a repository"**
4. **Click "GitHub"**
5. **Find your "food-calendar-app"** in the list and click it
6. **Fill in these boxes EXACTLY:**
   - **Name:** `my-food-calendar`
   - **Region:** Same as your database
   - **Branch:** `main`
   - **Root Directory:** Leave this EMPTY
   - **Runtime:** `Node`
   - **Build Command:** `npm install && npm run build`
   - **Start Command:** `npm start`
   - **Plan:** Make sure it says "Free"

### 2D: Connect Your Database
1. **Scroll down to "Environment Variables"**
2. **Click "Add Environment Variable"**
3. **First one:**
   - **Key:** `NODE_ENV`
   - **Value:** `production`
4. **Click "Add Environment Variable" again**
5. **Second one:**
   - **Key:** `DATABASE_URL`
   - **Value:** Paste that long database text you copied earlier
6. **Click "Create Web Service"**

### 2E: Wait for It to Build
1. **You'll see lots of text scrolling** - this is normal!
2. **Wait 5-10 minutes** 
3. **When it says "Your service is live"**, you're almost done!

---

## STEP 3: Set Up Your Database (1 minute)

1. **Click on your web service name** in Render
2. **Look for a tab that says "Shell"** - click it
3. **Wait for it to load** (you'll see a cursor blinking)
4. **Type exactly:** `npm run db:push`
5. **Press Enter** and wait until it says "Success"

---

## 🎉 YOU'RE DONE!

### Your App is Now Online!
1. **Look for the URL at the top** of your Render page (looks like: https://my-food-calendar.onrender.com)
2. **Click it** to see your food calendar app
3. **Try adding a food** to make sure it works
4. **Share this URL** with anyone you want to use your app!

### What You Get for Free:
- Your own website that works on phones and computers
- Automatic security (HTTPS)
- 750 hours per month (basically always on)
- 1GB of storage for your food data

### Important Things to Know:
- **If no one visits for 15 minutes**, the site "sleeps" but wakes up when someone visits (takes 30-60 seconds)
- **Your data stays for 90 days** for free, then you'd need to pay $7/month to keep it forever
- **Every time you update your code** on GitHub, your website updates automatically!

### Need Help?
- Check if you typed everything exactly as shown
- Make sure you picked "Free" for everything
- Look at the "Logs" tab in Render if something seems broken
- The most common mistake is typing the Build Command or Start Command wrong

**Congratulations! Your food calendar app is now live on the internet!** 🎉