# Deploy to Render - Step by Step Guide

## Overview
This guide will help you deploy your AllergyTracker food calendar application to Render for free. The process takes about 10-15 minutes.

## Prerequisites
- A GitHub account
- A Render account (sign up at render.com - it's free)
- Your code pushed to a GitHub repository

## Step 1: Prepare Your Code for GitHub

1. **Create a new repository on GitHub:**
   - Go to github.com and click "New repository"
   - Name it something like "allergy-tracker" or "food-calendar"
   - Make it public (required for free Render deployment)
   - Don't initialize with README (we'll push existing code)

2. **Push your code to GitHub:**
   ```bash
   # In your project directory
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO_NAME.git
   git push -u origin main
   ```

## Step 2: Set Up Database on Render

1. **Create a PostgreSQL database:**
   - Log in to render.com
   - Click "New +" → "PostgreSQL"
   - Name: `allergy-tracker-db`
   - Database: `allergytracker`
   - User: `allergytracker`
   - Region: Choose closest to you
   - Plan: Free (0GB storage, expires in 90 days)
   - Click "Create Database"

2. **Get database connection info:**
   - Once created, go to your database dashboard
   - Copy the "External Database URL" - you'll need this later

## Step 3: Deploy Web Service

1. **Create a new Web Service:**
   - In Render dashboard, click "New +" → "Web Service"
   - Connect your GitHub repository
   - Select your repository from the list

2. **Configure the service:**
   - Name: `allergy-tracker-app`
   - Region: Same as your database
   - Branch: `main`
   - Root Directory: leave empty
   - Runtime: `Node`
   - Build Command: `npm install && npm run build`
   - Start Command: `npm start`
   - Plan: Free

3. **Add environment variables:**
   - Scroll down to "Environment Variables"
   - Add these variables:
     ```
     DATABASE_URL = [paste your database URL from step 2]
     NODE_ENV = production
     ```

4. **Deploy:**
   - Click "Create Web Service"
   - Wait for deployment (5-10 minutes)
   - Your app will be available at `https://your-app-name.onrender.com`

## Step 4: Initialize Database Schema

1. **Access your deployed app:**
   - Open your app URL in a browser
   - The app may show errors initially - this is normal

2. **Run database migrations:**
   - In your Render dashboard, go to your web service
   - Click "Shell" tab
   - Run: `npm run db:push`
   - This creates the necessary database tables

## Step 5: Test Your Application

1. **Verify functionality:**
   - Visit your app URL
   - Try adding a food item
   - Check if calendar displays properly
   - Test Apple Calendar export

2. **Troubleshoot if needed:**
   - Check logs in Render dashboard
   - Verify database connection
   - Ensure environment variables are set correctly

## Important Notes

### Free Tier Limitations
- **Database**: 1GB storage, expires after 90 days
- **Web Service**: 750 hours/month (enough for constant uptime)
- **Custom domains**: Not available on free tier
- **Sleep mode**: App sleeps after 15 minutes of inactivity

### Keeping Your App Active
- Free apps sleep after 15 minutes of inactivity
- They wake up automatically when accessed (takes 30-60 seconds)
- Use a service like UptimeRobot to ping your app every 14 minutes

### Database Persistence
- Free database expires after 90 days
- Upgrade to paid plan ($7/month) for persistent storage
- Export data before expiration if staying on free tier

## Upgrade Options

If you need more reliability:
- **Starter Plan**: $7/month for persistent database
- **Professional Plan**: $25/month for better performance
- **Custom domains**: Available on paid plans

## Troubleshooting

### Common Issues

1. **Build fails:**
   - Check that all dependencies are in package.json
   - Ensure build command is correct

2. **Database connection errors:**
   - Verify DATABASE_URL is correct
   - Check if database is running

3. **App doesn't load:**
   - Check logs in Render dashboard
   - Verify start command is correct

### Getting Help
- Render documentation: docs.render.com
- Render community forum: community.render.com
- GitHub issues for this project

## Next Steps

After successful deployment:
1. Share your app URL with others
2. Consider upgrading to paid plan for persistence
3. Set up monitoring with UptimeRobot
4. Add custom domain (paid feature)

Your food calendar app is now live and accessible worldwide!