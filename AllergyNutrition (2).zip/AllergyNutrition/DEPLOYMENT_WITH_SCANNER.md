# 🚀 Deploy Your Food Calendar App with Camera Scanner

## You've Successfully Added: AI Camera Scanner Feature!

Your app now includes:
- ✅ Calendar interface with food scheduling
- ✅ AI-powered camera scanner that reads handwritten calendars
- ✅ OpenAI Vision integration for handwriting recognition
- ✅ Mobile-friendly photo capture and upload
- ✅ Automatic food detection and scheduling

---

## Required Files for Complete Deployment

### Critical Files You Need to Update on GitHub:

**1. Updated server/routes.ts** (Contains scanner API endpoint)
**2. New client/src/components/CalendarScanner.tsx** (Scanner component)
**3. Updated client/src/pages/calendar.tsx** (Scanner button added)

---

## STEP 1: Update GitHub Repository

Since you added the scanner feature, you need to update these files on GitHub:

### Update server/routes.ts
1. Go to your GitHub repository
2. Navigate to `server/routes.ts`
3. Click "Edit this file" (pencil icon)
4. Replace the content with the new version from Replit
5. This file now includes the `/api/scan-calendar` endpoint

### Add CalendarScanner.tsx
1. In GitHub, create new file: `client/src/components/CalendarScanner.tsx`
2. Copy the entire content from Replit
3. This is the new camera scanner component

### Update calendar.tsx
1. Navigate to `client/src/pages/calendar.tsx` on GitHub
2. Edit and replace with updated version from Replit
3. This now includes the "Scan" button

---

## STEP 2: Deploy to Render

### A. Create PostgreSQL Database
1. Go to render.com and sign in with GitHub
2. Click "New +" → "PostgreSQL"
3. Name: `food-calendar-db`
4. Plan: Free
5. Click "Create Database"
6. **Copy the External Database URL** (starts with postgresql://)

### B. Create Web Service
1. Click "New +" → "Web Service"
2. Connect your GitHub repo: `food-calendar-app`
3. Configure:
   - **Name:** `food-calendar-app`
   - **Environment:** Node
   - **Plan:** Free
   - **Build Command:** `npm install && npm run build`
   - **Start Command:** `npm start`

### C. Set Environment Variables
1. In your web service settings, add:
   - **NODE_ENV** = `production`
   - **DATABASE_URL** = (paste your PostgreSQL URL)
   - **OPENAI_API_KEY** = (your OpenAI API key for scanner)

---

## STEP 3: Initialize Database

1. After deployment succeeds, go to your web service
2. Click "Shell" tab
3. Run: `npm run db:push`
4. This creates the food and schedule tables

---

## STEP 4: Test Your Live App

Your app will be live at: `https://food-calendar-app-[random].onrender.com`

### Test Features:
1. ✅ Add foods manually
2. ✅ View calendar with scheduling
3. ✅ Export to Apple Calendar
4. ✅ **NEW: Click "Scan" to test camera scanner**
5. ✅ Take photo of handwritten food list
6. ✅ Watch AI detect foods and frequencies

---

## 🎉 You're Done!

Your food calendar app with AI camera scanner is now live and hosted for free!

### What Works:
- Full calendar interface
- Food scheduling with smart frequencies
- Apple Calendar export with recurring events
- **AI camera scanner reads handwritten food lists**
- Mobile-responsive design
- Persistent PostgreSQL database

### Next Steps:
- Share your app URL with friends and family
- Test the scanner with different handwriting styles
- The app automatically syncs across all devices

**The scanner can read handwriting like:**
- "Egg - 3 times per week"
- "Milk daily" 
- "Apple every 2 days"
- "Vitamins once a week"

---

**🔑 Key Innovation:** Your app now combines traditional digital scheduling with AI-powered handwriting recognition, making it incredibly easy to digitize existing paper calendars!