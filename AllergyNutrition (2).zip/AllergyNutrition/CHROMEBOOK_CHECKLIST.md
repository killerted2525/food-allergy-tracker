# Chromebook Deployment Checklist - Copy-Paste Method

## ✅ Step 1: Create GitHub Account & Repository

1. **Go to github.com and sign up** (if you don't have an account)
2. **Click the green "New" button**
3. **Repository name:** `food-calendar-app`
4. **Make sure "Public" is selected**
5. **Click "Create repository"**

---

## ✅ Step 2: Copy Files One by One (Essential Files Only)

**For each file below, do this:**
1. **In GitHub: Click "Create new file"**
2. **In Replit: Click on the file name**
3. **Select all text (Ctrl+A) and copy (Ctrl+C)**
4. **In GitHub: Paste (Ctrl+V) and click "Commit new file"**

### Required Files (Copy in this order):

□ **File 1:** `package.json`
□ **File 2:** `package-lock.json`
□ **File 3:** `tsconfig.json`
□ **File 4:** `vite.config.ts`
□ **File 5:** `tailwind.config.ts`
□ **File 6:** `postcss.config.js`
□ **File 7:** `components.json`
□ **File 8:** `drizzle.config.ts`

### Client Files:
□ **File 9:** `client/index.html` (type the full path in GitHub)
□ **File 10:** `client/src/main.tsx`
□ **File 11:** `client/src/App.tsx`

### Server Files:
□ **File 12:** `server/index.ts`
□ **File 13:** `server/routes.ts`
□ **File 14:** `server/db.ts`
□ **File 15:** `server/storage.ts`
□ **File 16:** `server/vite.ts`

### Shared Files:
□ **File 17:** `shared/schema.ts`

### API Files:
□ **File 18:** `api/index.ts`

---

## ✅ Step 3: Deploy to Render

1. **Go to render.com**
2. **Click "Get Started for Free"**
3. **Sign up with GitHub**
4. **Click "Authorize Render"**

### Create Database:
5. **Click blue "New +" button**
6. **Click "PostgreSQL"**
7. **Name:** `food-calendar-db`
8. **Database:** `foodcalendar`
9. **User:** `fooduser`
10. **Plan:** Free
11. **Click "Create Database"**
12. **Wait 2 minutes, then copy the "External Database URL"**

### Create Web Service:
13. **Click "New +" again**
14. **Click "Web Service"**
15. **Connect your GitHub repository**
16. **Select "food-calendar-app"**
17. **Fill in exactly:**
    - **Name:** `my-food-calendar`
    - **Build Command:** `npm install && npm run build`
    - **Start Command:** `npm start`
    - **Plan:** Free

### Add Environment Variables:
18. **Scroll to "Environment Variables"**
19. **Add Variable 1:**
    - **Key:** `NODE_ENV`
    - **Value:** `production`
20. **Add Variable 2:**
    - **Key:** `DATABASE_URL`
    - **Value:** (paste your database URL)
21. **Click "Create Web Service"**

---

## ✅ Step 4: Initialize Database

1. **Wait for deployment to finish (5-10 minutes)**
2. **Click "Shell" tab in your web service**
3. **Type:** `npm run db:push`
4. **Press Enter and wait for "Success"**

---

## ✅ Step 5: Test Your App

1. **Click the URL at the top of your Render dashboard**
2. **Try adding a food item**
3. **Test the calendar features**
4. **Share your URL with others!**

---

## 🎉 You're Done!

Your food calendar app is now live on the internet! The URL will be something like: `https://my-food-calendar.onrender.com`

### If You Get Stuck:
- **Build fails:** Check that all file names are spelled exactly right
- **App won't load:** Make sure DATABASE_URL is pasted correctly
- **Missing files:** Go back and copy any files you missed from the checklist

**This method works because we're copying the actual code content instead of dealing with zip files that don't extract properly on Chromebooks.**