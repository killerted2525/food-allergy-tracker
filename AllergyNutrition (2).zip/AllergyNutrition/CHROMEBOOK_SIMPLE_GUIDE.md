# Chromebook: Put Your Food App Online - Super Easy Steps

## If Linux Isn't Set Up Yet

### Finding Linux Settings (Try These in Order):
**Method 1:**
1. **Click the time** (bottom-right corner)
2. **Click the gear** (Settings)
3. **Look on the left side** for "Apps" and click it
4. **Look for "Linux development environment"** and turn it on

**Method 2:**
1. **Click the time** (bottom-right corner)
2. **Click the gear** (Settings)
3. **Click "About Chrome OS"** at the bottom left
4. **Click "Additional details"**
5. **Look for "Linux development environment"** and turn it on

**Method 3:**
1. **Click the launcher** (circle icon in taskbar)
2. **Type "linux"** in the search
3. **If you see "Linux (Beta)" click it**
4. **If not, try typing "terminal"**

**If none of these work:** Your Chromebook might not support Linux. That's okay! We can use a different method.

## Method 1: With Linux Terminal

### Step 1: Get Your Code Ready
1. **Go back to this Replit tab**
2. **Click the 3 dots** next to "Files"
3. **Click "Download as zip"**
4. **Save to Downloads**

### Step 2: Extract the Zip File
1. **Open Files app** (click the folder icon in your taskbar)
2. **Click "Downloads"** on the left
3. **Find your zip file** (probably called "repl-export.zip")
4. **Right-click the zip file**
5. **Click "Extract all"**
6. **A folder appears** - remember its name!

### Step 3: Open Terminal
1. **Press Ctrl + Alt + T**
2. **Type:** shell
3. **Press Enter**

### Step 4: Navigate to Your Code
1. **Type:** `cd Downloads`
2. **Type:** `ls` (this shows your files)
3. **Type:** `cd` followed by your folder name (like `cd repl-export`)

### Step 5: Install Git (if needed)
1. **Type:** `git --version`
2. **If it says "not found", type:**
   ```
   sudo apt update
   sudo apt install git
   ```

## Method 2: No Linux Needed (Easier!)

### Step 1: Use GitHub's Web Interface
1. **Go to github.com** and sign up
2. **Click "New repository"**
3. **Name it:** `food-calendar-app`
4. **Make it Public**
5. **Click "Create repository"**

### Step 2: Upload Files Directly
1. **Click "uploading an existing file"** (blue link on the page)
2. **Go back to Replit** and download your zip
3. **Extract the zip** using the Files app method above
4. **Go back to GitHub**
5. **Drag ALL the files** from your extracted folder into the GitHub page
6. **Scroll down and click "Commit changes"**

**This method skips the terminal completely!**

## Next Steps: Create Your Website

1. **Go to render.com**
2. **Sign up with GitHub**
3. **Create a PostgreSQL database** (free)
4. **Create a Web Service** using your GitHub repo
5. **Add environment variables**
6. **Wait for deployment**

**Your app will be live at a URL like:** `https://your-app-name.onrender.com`

## Need Help?

**Can't find Linux settings?** Use Method 2 (no terminal needed)

**Zip file won't extract?** Try double-clicking it instead of right-clicking

**Terminal not working?** Use Method 2 with GitHub's web upload

**Still stuck?** The web upload method (Method 2) works on every Chromebook and is actually easier!

The web upload method is often the best choice for Chromebooks because it doesn't require any special setup.