# Deploy Your Food Calendar App from Chromebook - Simple Guide

## What This Does
This guide will help you put your food calendar app on the internet so anyone can use it from their phone or computer. It's completely free and works perfectly on your Chromebook!

---

## STEP 1: Save Your Code Online (GitHub)

### 1A: Create a GitHub Account
1. **Go to github.com** in your Chrome browser
2. **Look for a green button that says "Sign up"** - click it
3. **Type in your email** and make up a password
4. **Pick a username** (like johnsmith123)
5. **Click "Create account"**
6. **Check your email** and click the link they send you

### 1B: Make a Place for Your Code
1. **After logging in**, look for a **green button that says "New"** - click it
2. **Type "food-calendar-app"** in the box that says "Repository name"
3. **Make sure the circle next to "Public" is filled in** (NOT "Private")
4. **Do NOT check any boxes** below that
5. **Click the green "Create repository" button**

### 1C: Put Your Code There (Chromebook Method)
1. **Keep that GitHub page open** - you'll need it
2. **Go back to this Replit tab**
3. **Click the 3 dots** next to "Files" on the left side
4. **Click "Download as zip"**
5. **Save it to your Downloads folder**

**How to extract the zip file on Chromebook:**
1. **Open the Files app** (click the circle icon in your taskbar or find "Files" in your apps)
2. **Click "Downloads"** on the left side
3. **Find your zip file** (it will be named something like "repl-export.zip")
4. **Right-click on the zip file**
5. **Click "Extract all"** or **"Extract here"**
6. **A new folder will appear** with all your code files inside
7. **Remember the name of this folder** - you'll need it for the next step

**Setting up Terminal on Chromebook:**
1. **Press Ctrl + Alt + T** - this opens the Chrome terminal
2. **Type "shell"** and press Enter
3. **A Linux terminal opens** - this is normal and safe!

**If this is your first time using Linux on Chromebook:**
1. **Click the time** in the bottom-right corner
2. **Click the gear icon** (Settings)
3. **Look for "Apps"** in the left menu and click it
4. **Look for "Manage your apps"** or scroll down to find **"Linux development environment"**
5. **Click "Turn on"** next to Linux development environment
6. **Wait for it to install** (5-10 minutes)
7. **Open Terminal** from your app launcher (it might be called "Terminal" or "Linux")

**Putting your code on GitHub:**
1. **In the terminal, type:** `cd Downloads`
2. **Type:** `ls` (this shows your files - look for your unzipped folder)
3. **Type:** `cd` followed by your folder name (like `cd food-calendar-app`)
4. **Check if git is installed by typing:** `git --version`
5. **If it says "command not found", install git:**
   ```
   sudo apt update
   sudo apt install git
   ```
   (Type your Chromebook password when asked)

**Now upload your code:**
1. **Copy and paste these commands ONE AT A TIME** (press Enter after each):

```
git init
```
(Press Enter and wait)

```
git add .
```
(Press Enter and wait)

```
git commit -m "My food calendar app"
```
(Press Enter and wait)

```
git branch -M main
```
(Press Enter and wait)

2. **Go back to your GitHub page** and copy the line that starts with "git remote add origin"
3. **Paste it in terminal** and press Enter
4. **Copy the line that starts with "git push"** from GitHub
5. **Paste it in terminal** and press Enter
6. **When asked for username:** type your GitHub username
7. **When asked for password:** you need a "token" (see below)

**Getting a GitHub Token (required for Chromebook):**
1. **On GitHub, click your profile picture** (top-right)
2. **Click "Settings"**
3. **Scroll down and click "Developer settings"**
4. **Click "Personal access tokens"** → **"Tokens (classic)"**
5. **Click "Generate new token"** → **"Generate new token (classic)"**
6. **Give it a name** like "My Chromebook"
7. **Check the "repo" box**
8. **Click "Generate token"**
9. **Copy the token** (it starts with "ghp_") and use this as your password

---

## STEP 2: Make It a Real Website (Render)

### 2A: Create a Render Account
1. **Go to render.com** in a new tab
2. **Click "Get Started for Free"**
3. **Click the "GitHub" button** (don't type anything)
4. **Click "Authorize Render"** when it asks

### 2B: Make a Database (Where Your Food Info is Saved)
1. **Look for a blue button that says "New +"** - click it
2. **Click "PostgreSQL"**
3. **Fill in these boxes EXACTLY:**
   - **Name:** `food-calendar-db`
   - **Database:** `foodcalendar`
   - **User:** `fooduser`
   - **Region:** Pick the one closest to where you live
   - **Plan:** Make sure it says "Free"
4. **Click "Create Database"**
5. **Wait 2 minutes** - it will say "Available" when ready
6. **Click on the database name**
7. **Scroll down until you see "External Database URL"**
8. **Click the copy button** next to the long text (starts with "postgresql://")
9. **Paste this in a note** - you need it for the next step

### 2C: Make Your Website
1. **Click that blue "New +" button** again
2. **Click "Web Service"**
3. **Click "Connect a repository"**
4. **Click "GitHub"**
5. **Find your "food-calendar-app"** in the list and click it
6. **Fill in these boxes EXACTLY:**
   - **Name:** `my-food-calendar`
   - **Region:** Same as your database
   - **Branch:** `main`
   - **Root Directory:** Leave this EMPTY
   - **Runtime:** `Node`
   - **Build Command:** `npm install && npm run build`
   - **Start Command:** `npm start`
   - **Plan:** Make sure it says "Free"

### 2D: Connect Your Database
1. **Scroll down to "Environment Variables"**
2. **Click "Add Environment Variable"**
3. **First one:**
   - **Key:** `NODE_ENV`
   - **Value:** `production`
4. **Click "Add Environment Variable" again**
5. **Second one:**
   - **Key:** `DATABASE_URL`
   - **Value:** Paste that long database text you copied earlier
6. **Click "Create Web Service"**

### 2E: Wait for It to Build
1. **You'll see lots of text scrolling** - this is normal!
2. **Wait 5-10 minutes** 
3. **When it says "Your service is live"**, you're almost done!

---

## STEP 3: Set Up Your Database (1 minute)

1. **Click on your web service name** in Render
2. **Look for a tab that says "Shell"** - click it
3. **Wait for it to load** (you'll see a cursor blinking)
4. **Type exactly:** `npm run db:push`
5. **Press Enter** and wait until it says "Success"

---

## 🎉 YOU'RE DONE!

### Your App is Now Online!
1. **Look for the URL at the top** of your Render page (looks like: https://my-food-calendar.onrender.com)
2. **Click it** to see your food calendar app
3. **Try adding a food** to make sure it works
4. **Share this URL** with anyone you want to use your app!

### Chromebook Specific Tips:
- **Your Linux files** are in a separate area from your regular Chrome OS files
- **The terminal is safe to use** - it's just another way to talk to your computer
- **If you close the terminal**, press Ctrl + Alt + T and type "shell" to get back
- **Your app works great on Chromebooks** and will work on any device with a web browser

### What You Get for Free:
- Your own website that works on phones and computers
- Automatic security (HTTPS)
- 750 hours per month (basically always on)
- 1GB of storage for your food data

### Important Things to Know:
- **If no one visits for 15 minutes**, the site "sleeps" but wakes up when someone visits (takes 30-60 seconds)
- **Your data stays for 90 days** for free, then you'd need to pay $7/month to keep it forever
- **Every time you update your code** on GitHub, your website updates automatically!

### Need Help?
- Check if you typed everything exactly as shown
- Make sure you picked "Free" for everything
- Look at the "Logs" tab in Render if something seems broken
- If git commands don't work, make sure Linux is enabled in Settings

**Congratulations! Your food calendar app is now live on the internet from your Chromebook!** 🎉