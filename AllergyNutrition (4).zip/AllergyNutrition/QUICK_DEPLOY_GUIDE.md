# Deploy Your Food Calendar App to Render - Simple Guide

## What You'll Need (Total Time: 10 minutes)
- A computer with internet
- An email address
- Your food calendar app code (which you have right here!)

---

## PART 1: Put Your Code on GitHub (4 minutes)

### Step 1.1: Create a GitHub Account
1. **Open your web browser** and go to **github.com**
2. **Click the green "Sign up" button** in the top-right corner
3. **Enter your email address** and create a password
4. **Choose a username** (like "yourname123")
5. **Click "Create account"** and verify your email

### Step 1.2: Create a New Repository
1. **After signing in**, click the **green "New" button** (top-left area)
2. **Repository name**: Type `food-calendar-app`
3. **Make sure "Public" is selected** (this must be checked for free hosting!)
4. **Do NOT check** "Add a README file"
5. **Do NOT check** "Add .gitignore"
6. **Click the green "Create repository" button**

### Step 1.3: Upload Your Code
1. **You'll see a page with commands** - keep this page open
2. **Copy the repository URL** from the page (it looks like: `https://github.com/yourusername/food-calendar-app.git`)
3. **Download all your code files** from this Replit project:
   - Click the **three dots menu** in the file explorer
   - Select **"Download as zip"**
   - **Extract the zip file** to your computer
4. **Open Terminal/Command Prompt**:
   - **Windows**: Press `Windows key + R`, type `cmd`, press Enter
   - **Mac**: Press `Cmd + Space`, type `terminal`, press Enter
5. **Navigate to your code folder**:
   - Type: `cd Downloads/your-extracted-folder-name`
   - Press Enter
6. **Run these commands one by one** (press Enter after each):
   ```
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/YOURUSERNAME/food-calendar-app.git
   git push -u origin main
   ```
   (Replace YOURUSERNAME with your actual GitHub username)

---

## PART 2: Create Your Free Website on Render (6 minutes)

### Step 2.1: Sign Up for Render
1. **Open a new tab** and go to **render.com**
2. **Click "Get Started for Free"**
3. **Click "GitHub"** to sign up using your GitHub account
4. **Click "Authorize Render"** when GitHub asks

### Step 2.2: Create a Database (2 minutes)
1. **In your Render dashboard**, click the **blue "New +"** button
2. **Click "PostgreSQL"**
3. **Fill in these details**:
   - **Name**: `food-calendar-db`
   - **Database**: `foodcalendar`
   - **User**: `fooduser`
   - **Region**: Choose the one closest to you
   - **PostgreSQL Version**: Leave as default
   - **Plan**: Make sure **"Free"** is selected
4. **Click "Create Database"**
5. **Wait 1-2 minutes** for it to be created
6. **Once ready, click on your database name**
7. **Scroll down and copy the "External Database URL"** (it's a long text starting with "postgresql://")
8. **Paste this URL somewhere safe** (like Notepad) - you'll need it in the next step

### Step 2.3: Create Your Website (4 minutes)
1. **Click the blue "New +" button** again
2. **Click "Web Service"**
3. **Click "Connect a repository"** then **"GitHub"**
4. **Find and click your "food-calendar-app" repository**
5. **Fill in these exact settings**:
   - **Name**: `my-food-calendar`
   - **Region**: Same as your database
   - **Branch**: `main`
   - **Root Directory**: Leave empty
   - **Runtime**: `Node`
   - **Build Command**: `npm install && npm run build`
   - **Start Command**: `npm start`
   - **Plan**: Make sure **"Free"** is selected

### Step 2.4: Add Your Database Connection
1. **Scroll down to "Environment Variables"**
2. **Click "Add Environment Variable"**
3. **First variable**:
   - **Key**: `NODE_ENV`
   - **Value**: `production`
4. **Click "Add Environment Variable" again**
5. **Second variable**:
   - **Key**: `DATABASE_URL`
   - **Value**: Paste that long database URL you copied earlier
6. **Click "Create Web Service"**

### Step 2.5: Wait for Deployment
1. **You'll see logs scrolling** - this is normal!
2. **Wait 5-10 minutes** for the first deployment
3. **When you see "Your service is live"**, click the URL at the top

---

## PART 3: Set Up Your Database (1 minute)

### Step 3.1: Initialize the Database
1. **In your Render dashboard**, click on your web service name
2. **Click the "Shell" tab** at the top
3. **Wait for the terminal to load**
4. **Type this command exactly**: `npm run db:push`
5. **Press Enter and wait** until you see "Success"

---

## 🎉 Your App is Live!

### Test Your App
1. **Click the URL at the top of your Render dashboard**
2. **Try adding a food item** to make sure it works
3. **Test the calendar features**
4. **Share the URL with friends and family!**

### Your App Details
- **Your website URL**: `https://my-food-calendar.onrender.com` (or similar)
- **Free features**: 750 hours/month, SSL certificate, automatic updates
- **Database**: 1GB storage (lasts 90 days on free plan)

### Important Notes
- **App sleeps after 15 minutes** of no visitors (wakes up in 30-60 seconds when someone visits)
- **To keep it awake**: Use a service like UptimeRobot to ping your URL every 14 minutes
- **Free database expires in 90 days**: Upgrade to $7/month for permanent storage
- **Automatic updates**: When you update code on GitHub, your website updates automatically!

---

## Need Help?
- **Check your Render dashboard logs** if something isn't working
- **Make sure all the settings match exactly** what's written above
- **The most common issue**: Wrong Build Command or Start Command
- **Email support**: help@render.com