# Deploy AllergyTracker to Vercel - Complete Step-by-Step Guide

Follow these exact steps to get your app live on the internet for free! Every click is explained.

---

## PART 1: Create a GitHub Account (5 minutes)

### Step 1.1: Go to GitHub
1. Open your web browser
2. Type `github.com` in the address bar
3. Press Enter

### Step 1.2: Sign Up for GitHub
1. You'll see a page with a big green "Sign up" button
2. Click the green **"Sign up"** button
3. Fill out the form:
   - **Username**: Choose something like `yourname-dev` or `yourname123`
   - **Email**: Use your real email address
   - **Password**: Choose a strong password
4. Click the green **"Create account"** button
5. GitHub will send you an email - check your email and click the verification link
6. Complete any puzzle or verification GitHub asks for

---

## PART 2: Upload Your Code to GitHub (10 minutes)

### Step 2.1: Create a New Repository
1. After logging into GitHub, look for a green **"New"** button (usually in the top left)
2. Click the green **"New"** button
3. Fill out the repository form:
   - **Repository name**: Type `allergy-tracker` (or any name you like)
   - **Description**: Type `Food allergy tracking calendar app`
   - Leave "Public" selected (it's free)
   - Check the box that says **"Add a README file"**
4. Click the green **"Create repository"** button

### Step 2.2: Upload Your Project Files
1. You'll now see your new empty repository
2. Click the **"uploading an existing file"** link (it's a small blue link)
3. You have two options to upload files:

**Option A: Drag and Drop (Easier)**
1. Open your Replit project in another tab
2. Select all files in your Replit file explorer (Ctrl+A or Cmd+A)
3. Download them to your computer
4. Go back to GitHub
5. Drag all the files from your computer into the GitHub upload area

**Option B: Click to Upload**
1. Click **"choose your files"**
2. Navigate to where you downloaded your Replit files
3. Select all files and click "Open"

### Step 2.3: Commit the Files
1. Scroll down to the bottom of the page
2. In the "Commit changes" box, type: `Initial upload of AllergyTracker app`
3. Click the green **"Commit changes"** button
4. Wait for the upload to complete (you'll see a green checkmark)

---

## PART 3: Create a Vercel Account (3 minutes)

### Step 3.1: Go to Vercel
1. Open a new tab in your browser
2. Type `vercel.com` in the address bar
3. Press Enter

### Step 3.2: Sign Up with GitHub
1. You'll see a black page with a white **"Start Deploying"** button
2. Click **"Start Deploying"**
3. On the next page, click **"Continue with GitHub"**
4. GitHub will ask if you want to authorize Vercel - click **"Authorize Vercel"**
5. Vercel may ask for your name and team info - just fill it out normally

---

## PART 4: Deploy Your App (5 minutes)

### Step 4.1: Import Your Project
1. You should now see your Vercel dashboard
2. Click the **"Add New..."** button (usually blue, top right)
3. Select **"Project"** from the dropdown
4. You'll see a list of your GitHub repositories
5. Find your `allergy-tracker` repository
6. Click the **"Import"** button next to it

### Step 4.2: Configure the Deployment
1. Vercel will show you a "Configure Project" page
2. **Project Name**: Leave it as `allergy-tracker` or change if you want
3. **Framework Preset**: It should automatically detect "Vite" - leave this alone
4. **Build and Output Settings**: Don't change anything here
5. **Environment Variables**: We'll add this in the next step
6. Click the big blue **"Deploy"** button

### Step 4.3: Wait for Deployment
1. You'll see a page with animated dots and "Building..."
2. This takes about 2-3 minutes
3. Don't close the page - just wait
4. When it's done, you'll see "Congratulations!" with confetti

---

## PART 5: Add Your Database Connection (3 minutes)

### Step 5.1: Go to Project Settings
1. After deployment, you'll see three buttons: "Continue to Dashboard", "Visit", and other options
2. Click **"Continue to Dashboard"**
3. You'll see your project in the dashboard
4. Click on your project name (`allergy-tracker`)
5. At the top of the page, click the **"Settings"** tab

### Step 5.2: Add Environment Variables
1. In the left sidebar, click **"Environment Variables"**
2. You'll see a form to add variables
3. In the **"Name"** field, type: `DATABASE_URL`
4. In the **"Value"** field, paste your database connection string from Replit
   - To find this in Replit: Look for `DATABASE_URL` in your environment variables
   - It looks like: `postgresql://username:password@host:5432/database`
5. Make sure **"Production"** is selected
6. Click **"Save"**

### Step 5.3: Redeploy with Database
1. Go back to the **"Deployments"** tab (top of the page)
2. You'll see your latest deployment
3. Click the three dots (**"..."**) next to the latest deployment
4. Click **"Redeploy"**
5. In the popup, click **"Redeploy"** again
6. Wait 2-3 minutes for it to rebuild

---

## PART 6: Your App is Live! (1 minute)

### Step 6.1: Visit Your Live App
1. After the redeploy finishes, click the **"Visit"** button
2. Your app will open in a new tab at a URL like: `https://allergy-tracker.vercel.app`
3. Test it out - add a food, check the calendar, try the support button!

### Step 6.2: Share Your App
- Your app URL is permanent - save it!
- You can share this URL with anyone
- It works on phones, tablets, and computers

---

## TROUBLESHOOTING

### If the app doesn't load:
1. Go back to Vercel dashboard
2. Click **"Functions"** tab
3. Look for any red error messages
4. Most common issue: DATABASE_URL not set correctly

### If you get a database error:
1. Double-check your DATABASE_URL in Vercel settings
2. Make sure there are no extra spaces
3. The URL should start with `postgresql://`

### If you need to update your app:
1. Go to your GitHub repository
2. Upload new files (drag and drop works)
3. Vercel automatically rebuilds your app!

---

## WHAT YOU NOW HAVE:

✅ **Professional web app** - Works like any website  
✅ **Free forever** - No monthly payments  
✅ **Automatic updates** - Change code, app updates  
✅ **Mobile friendly** - Works perfectly on phones  
✅ **Secure HTTPS** - Professional security  
✅ **Fast worldwide** - Loads quickly everywhere  
✅ **Your own URL** - Share with anyone  

**Your app is now live on the internet! Anyone in the world can use it by visiting your Vercel URL.**