#!/bin/bash

# Deploy to Render - Quick Setup Script
# This script helps you prepare your code for deployment to Render

echo "🚀 Preparing AllergyTracker for Render deployment..."
echo ""

# Check if git is initialized
if [ ! -d ".git" ]; then
    echo "📝 Initializing Git repository..."
    git init
    git add .
    git commit -m "Initial commit - AllergyTracker food calendar app"
    git branch -M main
    echo "✅ Git repository initialized"
else
    echo "📝 Git repository already exists"
fi

echo ""
echo "🔧 Next steps:"
echo "1. Create a GitHub repository at https://github.com/new"
echo "2. Run these commands with your repository URL:"
echo "   git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO_NAME.git"
echo "   git push -u origin main"
echo ""
echo "3. Go to https://render.com and:"
echo "   - Sign up for a free account"
echo "   - Create a new PostgreSQL database"
echo "   - Create a new Web Service from your GitHub repo"
echo "   - Use these settings:"
echo "     Build Command: npm install && npm run build"
echo "     Start Command: npm start"
echo "     Environment Variables: DATABASE_URL (from your database)"
echo ""
echo "4. After deployment, run 'npm run db:push' in the Render shell to set up database tables"
echo ""
echo "📖 See RENDER_DEPLOYMENT.md for detailed step-by-step instructions"
echo "✨ Your app will be live at https://your-app-name.onrender.com"