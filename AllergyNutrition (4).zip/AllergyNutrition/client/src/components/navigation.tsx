import { Calendar, Plus, Settings } from "lucide-react";

interface NavigationProps {
  activeTab: 'calendar' | 'add-food' | 'manage-foods';
  onTabChange: (tab: 'calendar' | 'add-food' | 'manage-foods') => void;
}

export default function Navigation({ activeTab, onTabChange }: NavigationProps) {
  return (
    <nav className="bg-white border-b" style={{ borderColor: 'hsl(var(--apple-border))' }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex space-x-8">
          <button
            onClick={() => onTabChange('calendar')}
            className={`border-b-2 px-1 py-4 text-sm font-medium transition-colors ${
              activeTab === 'calendar'
                ? 'border-blue-500 text-blue-500'
                : 'border-transparent hover:text-gray-700'
            }`}
            style={{
              borderColor: activeTab === 'calendar' ? 'hsl(var(--apple-blue))' : 'transparent',
              color: activeTab === 'calendar' ? 'hsl(var(--apple-blue))' : 'hsl(var(--apple-medium))'
            }}
          >
            <Calendar size={16} className="mr-2 inline" />
            Calendar
          </button>
          <button
            onClick={() => onTabChange('add-food')}
            className={`border-b-2 px-1 py-4 text-sm font-medium transition-colors ${
              activeTab === 'add-food'
                ? 'border-blue-500 text-blue-500'
                : 'border-transparent hover:text-gray-700'
            }`}
            style={{
              borderColor: activeTab === 'add-food' ? 'hsl(var(--apple-blue))' : 'transparent',
              color: activeTab === 'add-food' ? 'hsl(var(--apple-blue))' : 'hsl(var(--apple-medium))'
            }}
          >
            <Plus size={16} className="mr-2 inline" />
            Add Food
          </button>
          <button
            onClick={() => onTabChange('manage-foods')}
            className={`border-b-2 px-1 py-4 text-sm font-medium transition-colors ${
              activeTab === 'manage-foods'
                ? 'border-blue-500 text-blue-500'
                : 'border-transparent hover:text-gray-700'
            }`}
            style={{
              borderColor: activeTab === 'manage-foods' ? 'hsl(var(--apple-blue))' : 'transparent',
              color: activeTab === 'manage-foods' ? 'hsl(var(--apple-blue))' : 'hsl(var(--apple-medium))'
            }}
          >
            <Settings size={16} className="mr-2 inline" />
            Manage Foods
          </button>
        </div>
      </div>
    </nav>
  );
}
