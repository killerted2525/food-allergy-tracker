interface LogoProps {
  size?: number;
  className?: string;
}

export default function Logo({ size = 32, className = "" }: LogoProps) {
  return (
    <div className={`relative ${className}`} style={{ width: size, height: size }}>
      <svg
        width={size}
        height={size}
        viewBox="0 0 32 32"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Background circle with gradient */}
        <defs>
          <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="hsl(207, 100%, 50%)" />
            <stop offset="100%" stopColor="hsl(248, 53%, 58%)" />
          </linearGradient>
          <linearGradient id="heartGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="hsl(4, 100%, 59%)" />
            <stop offset="100%" stopColor="hsl(322, 79%, 65%)" />
          </linearGradient>
        </defs>
        
        {/* Main circle */}
        <circle
          cx="16"
          cy="16"
          r="15"
          fill="url(#logoGradient)"
          stroke="rgba(255,255,255,0.2)"
          strokeWidth="1"
        />
        
        {/* Calendar grid - simplified */}
        <rect x="8" y="9" width="16" height="14" rx="2" fill="white" fillOpacity="0.9" />
        
        {/* Calendar header */}
        <rect x="8" y="9" width="16" height="3" rx="2" fill="white" />
        
        {/* Calendar dots representing days */}
        <circle cx="11" cy="15" r="1" fill="hsl(var(--apple-blue))" fillOpacity="0.6" />
        <circle cx="14" cy="15" r="1" fill="hsl(var(--apple-green))" fillOpacity="0.6" />
        <circle cx="17" cy="15" r="1" fill="hsl(var(--apple-orange))" fillOpacity="0.6" />
        <circle cx="21" cy="15" r="1" fill="hsl(var(--apple-purple))" fillOpacity="0.6" />
        
        <circle cx="11" cy="18" r="1" fill="hsl(var(--apple-red))" fillOpacity="0.6" />
        <circle cx="14" cy="18" r="1" fill="hsl(var(--apple-teal))" fillOpacity="0.6" />
        <circle cx="17" cy="18" r="1" fill="hsl(var(--apple-yellow))" fillOpacity="0.6" />
        
        <circle cx="11" cy="21" r="1" fill="hsl(var(--apple-pink))" fillOpacity="0.6" />
        <circle cx="14" cy="21" r="1" fill="hsl(var(--apple-mint))" fillOpacity="0.6" />
        
        {/* Small heart icon for health/allergy focus */}
        <path
          d="M19 17c0-1.5 1-2.5 2.5-2.5S24 15.5 24 17c0 1.5-2.5 4-2.5 4s-2.5-2.5-2.5-4z"
          fill="url(#heartGradient)"
          transform="scale(0.4) translate(14, 8)"
        />
      </svg>
    </div>
  );
}