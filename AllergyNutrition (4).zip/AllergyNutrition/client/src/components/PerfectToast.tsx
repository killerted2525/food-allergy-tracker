import { useToast } from "@/hooks/use-toast";
import { CheckCircle, AlertCircle, Camera, Sparkles } from "lucide-react";

interface PerfectToastProps {
  type: 'success' | 'error' | 'scan' | 'ai';
  title: string;
  description: string;
}

export function usePerfectToast() {
  const { toast } = useToast();

  const showPerfectToast = ({ type, title, description }: PerfectToastProps) => {
    const icons = {
      success: <CheckCircle className="w-5 h-5 text-green-500" />,
      error: <AlertCircle className="w-5 h-5 text-red-500" />,
      scan: <Camera className="w-5 h-5 text-blue-500" />,
      ai: <Sparkles className="w-5 h-5 text-purple-500" />
    };

    toast({
      title: (
        <div className="flex items-center gap-2">
          {icons[type]}
          <span>{title}</span>
        </div>
      ) as any,
      description,
      variant: type === 'error' ? 'destructive' : 'default',
      duration: type === 'success' ? 5000 : 4000,
    });
  };

  return { showPerfectToast };
}